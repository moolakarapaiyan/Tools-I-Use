
#!/system/bin/sh

MODDIR=\${0%/*}

# copy to system_root if available (Magisk v24+), and to legacy system as fallback

if [ -d "\$MODDIR/system_root" ]; then

  cp -f "\$MODDIR/system_root/etc/security/cacerts/"* /system_root/etc/security/cacerts/ 2>/dev/null || true

fi

if [ -d "\$MODDIR/system" ]; then

  cp -f "\$MODDIR/system/etc/security/cacerts/"* /system/etc/security/cacerts/ 2>/dev/null || true

fi

