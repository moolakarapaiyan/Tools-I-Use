import glob
import html
import socket
from urllib.parse import urlparse
from yattag import Doc, indent
from html import unescape
from flask import Flask, render_template
import subprocess
import time
from flask import Flask, redirect, url_for, render_template, request, session
import json
import sys
import os
from http.server import BaseHTTPRequestHandler
from io import BytesIO
from json import load
from urllib.parse import parse_qsl


class HTTPRequest(BaseHTTPRequestHandler):
    def __init__(self, raw_http_request):
        self.rfile = BytesIO(raw_http_request.encode('utf-8'))
        self.raw_requestline = self.rfile.readline()
        self.error_code = self.error_message = None
        self.parse_request()

        self.headers = dict(self.headers)
        # Data
        try:
            self.data = raw_http_request[raw_http_request.index(
                '\n\n')+2:].rstrip()
        except ValueError:
            self.data = None

        # Cookies
        self.cookies = {}
        raw_cookies = self.headers.get('cookie')
        if raw_cookies:
            for raw_cookie in raw_cookies.split(';'):
                cookie_parts = raw_cookie.split('=')
                cookie_name = cookie_parts[0].strip()
                cookie_value = ''.join(cookie_parts[1:]).strip()
                self.cookies[cookie_name] = cookie_value

    def send_error(self, code, message):
        self.error_code = code
        self.error_message = message


class xml_parser:

    def xml_maker(requestobj, raw_http_request):
        headers, data, method, request, uri, port, protocol, host, ipAdd, extension = parser(
            requestobj)
        doc, tag, text = Doc().tagtext()
    # with tag('items'):
        with tag('item'):
            with tag('url'):
                text("<![CDATA["+protocol+"://"+host+uri+"]]>")
            with tag('host', ip=ipAdd):
                text(host)
            with tag('port'):
                text(port)
            with tag("protocol"):
                text(protocol)
            with tag('method'):
                text("<![CDATA["+method+"]]>")
            with tag("path"):
                text("<![CDATA["+uri+"]]>")
            with tag("extension"):
                text(extension)
            with tag('request', base64="false"):
                text("<![CDATA["+raw_http_request+"]]>")

        result = indent(
            doc.getvalue(),
            indentation=' '*4,
            newline='\r\n'
        )

    xml_file = open("burpxml.xml", "a")
    xml_file.write(unescape(result))
    xml_file.close()

    def parser(request):

        parsed_url = urlparse(request.path)
        host_header_value = request.headers.get('host', None)
        scheme = parsed_url.scheme
        port = parsed_url.port
        head = request.headers
        host = head['Host']
        ip = socket.gethostbyname(host)
        port = "443"
        protocol = "https"
        extension = "null"

        parsed_url = urlparse(request.path)

        request.path = parsed_url.path
        if parsed_url.query:
            request.path += '?{}'.format(parsed_url.query)

        headers = request.headers
        data = request.data
        cookies = request.cookies
        method = request.command
        uri = request.path
        host = host
        port = port

        return headers, data, method, request, uri, port, protocol, host, ip, extension

    def main():
        header = """<?xml version=\"1.1\"?>
        <!DOCTYPE items [
        <!ELEMENT items (item*)>
        <!ATTLIST items burpVersion CDATA \"\">
        <!ATTLIST items exportTime CDATA \"\">
        <!ELEMENT item (time, url, host, port, protocol, method, path, extension, request, status, responselength, mimetype, response, comment)>
        <!ELEMENT time (#PCDATA)>
        <!ELEMENT url (#PCDATA)>
        <!ELEMENT host (#PCDATA)>
        <!ATTLIST host ip CDATA \"\">
        <!ELEMENT port (#PCDATA)>
        <!ELEMENT protocol (#PCDATA)>
        <!ELEMENT method (#PCDATA)>
        <!ELEMENT path (#PCDATA)>
        <!ELEMENT extension (#PCDATA)>
        <!ELEMENT request (#PCDATA)>
        <!ATTLIST request base64 (true|false) \"false\">
        <!ELEMENT status (#PCDATA)>
        <!ELEMENT responselength (#PCDATA)>
        <!ELEMENT mimetype (#PCDATA)>
        <!ELEMENT response (#PCDATA)>
        <!ATTLIST response base64 (true|false) \"false\">
        <!ELEMENT comment (#PCDATA)>
        ]>
        <items burpVersion=\"2022.3.9\" exportTime=\"Wed Jul 06 16:30:50 UTC 2022\">
        """
        xml_file = open("burpxml.xml", "a")
        xml_file.write(header)
        xml_file.close()

        filelist = [f for f in glob.glob("logs/*.txt")]

        for files in filelist:
            raw_http_request = ''.join(open(files, 'r').readlines())
            request = HTTPRequest(raw_http_request)
            if request:
                xml_maker(request, raw_http_request)

        xml_file = open("burpxml.xml", "a")
        xml_file.write("\n</items>")
        xml_file.close()


class server_attrib:

        app = Flask(__name__)

        @app.route("/button.html", methods=['GET', 'POST'])
    def butt():
        cmd = ['proxify', '-dump-req']
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
        for line in p.stdout:
            print(line)
                p.wait()
                print(p.returncode)
        return render_template("button.html")

        @app.route("/stop.html", methods=['GET', 'POST'])
        def stopme():
                os.system("ps -C proxify -o pid=|xargs kill -9")
                return render_template("stop.html")

        # rendering the HTML page which has the button
        @app.route('/')
        @app.route('/json')
        def json():
                return render_template('json.html')

        # background process happening without any refreshing
        @app.route('/background_process_start')
        def background_process_start():
                cmd = ['proxify', '-dump-req']
                p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
                for line in p.stdout:
                        print(line)
                p.wait()
                print(p.returncode)

                return render_template("button.html")

        @app.route('/background_process_stop')
        def background_process_stop():
                os.system("ps -C proxify -o pid=|xargs kill -9")
                # dir = os.getcwd()
                # file = open(dir+"/request_parser.py", 'r').read()
                # exec(file)
                return render_template("stop.html")

if __name__ == '__main__':
    app.run(debug=True)