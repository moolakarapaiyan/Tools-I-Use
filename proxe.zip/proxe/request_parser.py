import glob
import html
import socket
from urllib.parse import urlparse
from yattag import Doc, indent
from http_request import HTTPRequest
from html import unescape


def xml_maker(requestobj,raw_http_request):
    headers,data,method,request,uri,port,protocol,host,ipAdd,extension = parser(requestobj)
    doc, tag, text = Doc().tagtext()
    #with tag('items'):
    with tag('item'):
        with tag('url'):
            text("<![CDATA["+protocol+"://"+host+uri+"]]>")
        with tag('host', ip=ipAdd):
            text(host)
        with tag('port'):
            text(port)
        with tag("protocol"):
            text(protocol)
        with tag('method'):
            text("<![CDATA["+method+"]]>")
        with tag("path"):
            text("<![CDATA["+uri+"]]>")
        with tag("extension"):
            text(extension)
        with tag('request',base64="false"):
            text("<![CDATA["+raw_http_request+"]]>")

    result = indent(
        doc.getvalue(),
        indentation = ' '*4,
        newline = '\r\n'
    )
    
    xml_file = open("burpxml.xml", "a")
    xml_file.write(unescape(result))
    xml_file.close()



def parser(request):
    
    parsed_url = urlparse(request.path)
    host_header_value = request.headers.get('host', None)
    scheme = parsed_url.scheme
    port = parsed_url.port
    head = request.headers
    host = head['Host']
    ip = socket.gethostbyname(host)
    port = "443"
    protocol = "https"
    extension="null"
   
    parsed_url = urlparse(request.path)
        
    request.path = parsed_url.path
    if parsed_url.query:
        request.path += '?{}'.format(parsed_url.query) 

   
    headers=request.headers
    data=request.data
    cookies=request.cookies
    method=request.command
    uri=request.path
    host=host
    port=port
    
    return headers,data,method,request,uri,port,protocol,host,ip,extension


def main():
    header="""<?xml version=\"1.1\"?>
<!DOCTYPE items [
<!ELEMENT items (item*)>
<!ATTLIST items burpVersion CDATA \"\">
<!ATTLIST items exportTime CDATA \"\">
<!ELEMENT item (time, url, host, port, protocol, method, path, extension, request, status, responselength, mimetype, response, comment)>
<!ELEMENT time (#PCDATA)>
<!ELEMENT url (#PCDATA)>
<!ELEMENT host (#PCDATA)>
<!ATTLIST host ip CDATA \"\">
<!ELEMENT port (#PCDATA)>
<!ELEMENT protocol (#PCDATA)>
<!ELEMENT method (#PCDATA)>
<!ELEMENT path (#PCDATA)>
<!ELEMENT extension (#PCDATA)>
<!ELEMENT request (#PCDATA)>
<!ATTLIST request base64 (true|false) \"false\">
<!ELEMENT status (#PCDATA)>
<!ELEMENT responselength (#PCDATA)>
<!ELEMENT mimetype (#PCDATA)>
<!ELEMENT response (#PCDATA)>
<!ATTLIST response base64 (true|false) \"false\">
<!ELEMENT comment (#PCDATA)>
]>
<items burpVersion=\"2022.3.9\" exportTime=\"Wed Jul 06 16:30:50 UTC 2022\">
"""
    xml_file = open("burpxml.xml", "a")
    xml_file.write(header)
    xml_file.close()

    filelist = [f for f in glob.glob("logs/*.txt")]

    for files in filelist:
        raw_http_request = ''.join(open(files, 'r').readlines())
        request = HTTPRequest(raw_http_request)
        if request:
            xml_maker(request,raw_http_request)
    
    xml_file = open("burpxml.xml", "a")
    xml_file.write("\n</items>")
    xml_file.close()


if __name__ == '__main__':
    main()
  
