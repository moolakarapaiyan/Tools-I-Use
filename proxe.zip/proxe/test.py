import glob
import os
import time
dir_name = 'ilove/'
# Get list of all files only in the given directory
dir_name = 'ilove/'
# Get list of all files only in the given directory
list_of_files = filter( os.path.isfile,glob.glob(dir_name + '*') )
    
student_dictionary = {time.strftime('%m-%d-%Y-%H:%M:%S',time.gmtime(os.path.getmtime(file_path))) : file_path for file_path in list_of_files }

print(student_dictionary)